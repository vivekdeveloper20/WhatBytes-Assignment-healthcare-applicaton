# WhatBytes-Assignment
This is a python project assignment for on campus drive of WhatBytes.
